
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.net.*;
/*import java.awt.datatransfer.*; */

public class readfile extends Applet
{
 Label label1;
 TextField nomfichier;
 Checkbox cb;
 Button bouton;
 TextField dest;
 Button envoi;
 TextArea ta;
 String nomfich;
 Toolkit tk;
 Object clb;
 String donnees;

 public void init ()
 {
  tk = getToolkit();
  /*clb = tk.getSystemClipboard();*/
  nomfich = "";
  label1 = new Label ("Nom du fichier");
  add (label1);
  nomfichier = new TextField ("", 30);
  add (nomfichier);
  cb = new Checkbox ("binaire");
  add (cb); 
  bouton = new Button ("Lire");
  add (bouton);
  dest = new TextField ("", 30);
  add (dest);
  envoi = new Button ("Envoyer");
  add (envoi);
  ta = new TextArea ("");
  /*ta.setEditable(true);*/
  add (ta);
 }

 public void paint (Graphics g)
 {
  try
  {
   boolean checked = cb.getState();
   /*g.drawString ("Bonjour !", 20, 10);*/
   String s = "";
   /*File texte = new File ("d:\\java\\d1\\test1.txt");*/
   File texte = new File (nomfich);
   FileInputStream  flot = new FileInputStream (texte);
   /*
   File sortie = new File ("d:\\java\\d1\\sortie.txt");
   FileOutputStream flotsortie = new FileOutputStream (sortie);
   */
   /*byte [] carac = new byte[1];*/
   int carac;
   for (int i=0; ; i++)
   {
    carac = flot.read ();  
    if (carac == -1)
     break;
    if (checked)
    {
     if (i % 16 == 0)
      s = s + '\n';
     s = s + carac + ",";
    }
    else
     s = s + (char)carac;
    /*flotsortie.write (carac);*/
   }
   /*g.drawString (s, 20, 30);*/
   /*label1.setText (s);*/
   ta.setText (s);
   donnees = s;
   /*messageBox (s);*/
  }
  catch (Exception e)
  {
   if (!nomfich.equals(""))
    g.drawString ("Erreur:" + e.toString(), 20, 250);
  } 
 } 

 public boolean action (Event evt, Object arg)
 {
  if (evt.target instanceof Button)
  {
   String lab = (String) arg;
   if (lab.equals ("Lire"))
   {
    nomfich = nomfichier.getText();
    repaint();
    return true;
   } 
   else if (lab.equals ("Envoyer"))
   {
    try
    {
      URL url = new URL (getCodeBase(), dest.getText() + "?data=" + ta.getText());
  	AppletContext ctx = getAppletContext();
  	ctx.showDocument (url);
    }
    catch (Exception e)
    {
    }
    return true;
    
   }
   else
    return true;
  }
  else
   return true;
 } 

}
