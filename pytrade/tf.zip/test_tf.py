execfile('lc.py')
execfile('afchid.py')
execfile('lhsv.py')
execfile('srd.py')
execfile('tf.py')
c=cid('FR0003500008')
tf(c,12*60,120,16,3,60,0)

