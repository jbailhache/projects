#define DEFINSTR(str) } else if (!strcmp (str_instr(instr), str)) {
