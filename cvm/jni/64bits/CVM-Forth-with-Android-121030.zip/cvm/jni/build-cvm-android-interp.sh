arm-linux-gnueabi-gcc -w -g -static -o cvm-android -DINTERP -DSOCKET cvm.c dbg.c target.c 
