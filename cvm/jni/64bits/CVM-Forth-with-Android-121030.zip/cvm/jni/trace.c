
int trace (char *s)
{
}

