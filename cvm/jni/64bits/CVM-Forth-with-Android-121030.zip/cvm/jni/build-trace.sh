cc -w -g -o cvm-linux-comparm -DTRACE -DLINUXCOMP -DCOMPARM -DLINUX -DSOCKET cvm.c dbg.c target.c asm.c -lltdl
 

