cc -w -g -o cvm-linux-interp -DINTERP cvm.c dbg.c target.c
 

