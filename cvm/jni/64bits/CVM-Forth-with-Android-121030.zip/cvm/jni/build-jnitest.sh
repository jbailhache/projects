cc -w -g -o jnitest -DINTERP jnitest.c cvm.c dbg.c target.c
 

