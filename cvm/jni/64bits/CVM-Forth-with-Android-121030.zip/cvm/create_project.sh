/home/jacques/android-sdk-linux/tools/android create project \
--name cvm  \
--target 1 \
--path /home/jacques/cvm \
--package jacquesb.cvm \
--activity  cvm
