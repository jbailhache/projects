
char inputchar (void)
{
 return getchar();
}

void output (char *s)
{
 printf ("%s", s);
}


