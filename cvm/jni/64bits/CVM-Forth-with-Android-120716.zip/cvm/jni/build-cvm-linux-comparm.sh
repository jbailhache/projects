cc -w -g -o cvm-linux-comparm -DLINUXCOMP -DCOMPARM -DLINUX -DSOCKET cvm.c dbg.c target.c asm.c -lltdl
 

