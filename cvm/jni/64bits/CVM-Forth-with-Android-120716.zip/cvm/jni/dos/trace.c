
int trace (char *s)
{
}

