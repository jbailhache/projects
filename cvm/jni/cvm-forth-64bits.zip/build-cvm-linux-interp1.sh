cc -w -g -o cvm-linux-interp -DINTERP -DLINUX -DSOCKET cvm.c dbg.c target.c -lltdl
 

